<template>
	<div class="back-index" style=""><img data-v-f78eceae="" src="//oss.lanlanlife.com/0cb693ff233f886fa6df93545bd9567d_80x80.png"></div>
</template>

<style lang="scss" scoped>
	@import '../assets/css/function';
	.back-index {
		width: 40px;
		height: 40px;
		position: fixed;
		right: 20px;
		bottom: 80px;
	}
	
	.back-index img {
		width: 40px;
		height: 40px;
	}
</style>