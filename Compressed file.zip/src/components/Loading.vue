<template>
	<div class="loading">
		<img src="//oss1.lanlanlife.com/f5ed64b94f4bd995e5d8ea8dfda382a4_62x62.gif">
		<p>正在加载...</p>
	</div>
</template>

<style lang="scss" scoped>
	@import '../assets/css/function';
	
	.loading {
		text-align: center;
	}
</style>