import Vue from 'vue'

export default {

	COM_LOADING_STATUS (state, status) {
		state.loading = status
	},

}