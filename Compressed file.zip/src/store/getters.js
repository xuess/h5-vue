export default {
	loading: state => state.loading,

}