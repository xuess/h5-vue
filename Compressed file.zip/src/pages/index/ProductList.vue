<template>

	<div infinite-scroll-disabled="loading" infinite-scroll-immediate-check="false" infinite-scroll-distance="10" class="items">
		<div>
			<div class="" style="">
				<div class="sort-bar">
					<div class="sort-tool">
						<div class="s-box active">精选</div>
						<div class="s-box">销量</div>
						<div class="s-box">最新</div>
						<div class="s-box"><span>价格</span> <span class="sort-icon"><i class="asc"></i> <i class="dsc"></i></span></div>
					</div>
				</div>
			</div>
		</div>
		<a href="/saber/detail?activityId=6941dc6bc5744db382ac4c3b3ddcc675&amp;itemId=560449794145&amp;pid=mm_112040233_40946019_167804789&amp;forCms=1&amp;cid=&amp;_path=9001.CA.0.i.560449794145" class="" data-collection="_path=9001.CA.0.i.560449794145">
			<product-item></product-item>
		</a>
		<div class="loading" style="display: none;"><img src="//oss1.lanlanlife.com/f5ed64b94f4bd995e5d8ea8dfda382a4_62x62.gif">
			<p>正在加载...</p>
		</div>
	</div>
</template>

<script>
	import ProductItem from '@/pages/index/ProductItem'
	export default {
		name: 'ProductList',
		data() {
			return {
				msg: '',
			};
		},
		components: {
			ProductItem
		},
	};
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped lang="scss">
	/*@import '../assets/css/function.scss';*/
	
	.sort-bar {
		padding: .07rem .1rem;
		font-size: 0;
		background: #FFF;
	}
	
	.sort-bar a {
		position: relative;
		display: inline-block;
		width: 33.33%;
		line-height: 25px;
		font-size: 14px;
		color: #333;
		text-align: center;
	}
	
	.sort-bar .active {
		color: #FE312A;
	}
	
	.sort-tool {
		display: -webkit-box;
		display: -ms-flexbox;
		display: flex;
	}
	
	.sort-tool .s-box {
		-webkit-box-flex: 1;
		-ms-flex: 1;
		flex: 1;
	}
	
	.sort-tool .s-box {
		position: relative;
		line-height: 25px;
		font-size: 14px;
		color: #333;
		text-align: center;
	}
	
	.sort-tool .s-box.active {
		color: #FE312A;
	}
	
	.sort-icon {
		position: relative;
	}
	
	.sort-icon i.asc,
	.sort-icon i.dsc {
		width: 9px;
		height: 4px;
		cursor: pointer;
		position: absolute;
		left: 6px;
	}
	
	.sort-icon i.asc {
		top: 1px;
	}
	
	.sort-icon i.dsc {
		top: 9px;
	}
	
	.sort-icon i.asc:before,
	.sort-icon i.asc:after,
	.sort-icon i.dsc:before,
	.sort-icon i.dsc:after {
		content: '';
		border-style: solid;
		position: absolute;
		left: 0;
	}
	
	.sort-icon i.asc:before {
		border-width: 0 6px 6px 6px;
		border-color: transparent transparent #979797 transparent;
		top: 0;
	}
	
	.sort-icon i.asc:after {
		border-width: 0 6px 6px 6px;
		border-color: transparent transparent #fff transparent;
		top: 1px;
	}
	
	.sort-icon i.dsc:before {
		border-width: 6px 6px 0 6px;
		border-color: #979797 transparent transparent transparent;
		top: 0;
	}
	
	.sort-icon i.dsc:after {
		border-width: 6px 6px 0 6px;
		border-color: #fff transparent transparent transparent;
		top: -1px;
	}
	
	.sort-tool .s-box.active .sort-icon i.asc.on:before {
		border-color: transparent transparent #FE312A transparent;
	}
	
	.sort-tool .s-box.active .sort-icon i.dsc.on:before {
		border-color: #FE312A transparent transparent transparent;
	}
</style>